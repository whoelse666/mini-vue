export function toDisplayString(value) {
  return String(value);
}
