export function initProps(instance: any, rawProps: any) {
  instance.props = rawProps || {};
}

